package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {
  private Toolbar toolbar;
  private RecyclerView rv;
  private ArrayList<kelimeler> kelimelerListe;
  private kelimelerAdapter adapter;
  private veritabani vt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // anasayfa tasarımını yaptık reyclerview

        toolbar=findViewById(R.id.toolbar);
        rv=findViewById(R.id.rv);

        toolbar.setTitle("sözlük uygulamasi");
        setSupportActionBar(toolbar);
        vt=new veritabani(this);
        veritabanikopyala();
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        kelimelerListe=new  kelimelerDao().tumkelimeler(vt);

        adapter=new kelimelerAdapter(this,kelimelerListe);
        rv.setAdapter(adapter);
    }
//toolbarı çalıştır


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu,menu);
        //toolbar üzerindeki itemlara tıklanıldığında aramayı tetikttm
        MenuItem item=menu.findItem(R.id.action_ara);
        SearchView searchView=(SearchView) item.getActionView();
        searchView.setOnQueryTextListener(this);

        return super.onCreateOptionsMenu(menu);
    }
//VERİYİ GİRDİKTEN SONRA ARAMAYA BASARSANIZ VERİYİ GÖNDERİR arar
    @Override
    public boolean onQueryTextSubmit(String query) {

        Log.e("Gönderilen Arama:",query);
        return false;
    }
//Her harf girdiğinzde ve sildğinzde arama yapar
    @Override
    public boolean onQueryTextChange(String newText) {
        Log.e("Harf girdikçe:",newText);
        return false;
    }
    public void veritabanikopyala(){
        DatabaseCopyHelper databaseCopyHelper=new DatabaseCopyHelper(this);
        try {
            databaseCopyHelper.createDataBase();
        } catch (IOException e) {
            throw new RuntimeException();
        }
        databaseCopyHelper.openDataBase();


    }
}