package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class kelimelerAdapter extends RecyclerView.Adapter<kelimelerAdapter.CardTasarımTut>{
    private Context mContext;
    private List<kelimeler> kelimelerListe;

    public kelimelerAdapter(Context mContext, List<kelimeler> kelimelerListe) {
        this.mContext = mContext;
        this.kelimelerListe = kelimelerListe;
    }

    @NonNull
    @Override
    public CardTasarımTut onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.card_tasarim,parent,false);

        return new CardTasarımTut(view);
    }
//tıklanıldığında ne olacak
    @Override
    public void onBindViewHolder(@NonNull CardTasarımTut holder, int position) {
       final kelimeler kelime=kelimelerListe.get(position);
        holder.textViewEN.setText(kelime.getIngilizce());
        holder.textViewTR.setText(kelime.getTurkce());
   holder.kelime_card.setOnClickListener(new View.OnClickListener() {

       @Override
       //card tıklanıldığında hangi kelime seçildiyse onu gösterir
       public void onClick(View view) {
           Intent intent=new Intent(mContext,DetayActivity.class);
           intent.putExtra("nesne",kelime);
           mContext.startActivity(intent);
       }
   });
    }
//RRCY İÇİNDE SAYFADA KAÇ VERİ GÖSTERİLECEK
    @Override
    public int getItemCount() {
        return kelimelerListe.size();
    }

    //CARD VE TEXTVİEVLER ARASI GEÇİŞLERİ BURADAN BİRİBİRİNE BAĞLADIM
    public  class CardTasarımTut extends RecyclerView.ViewHolder{
        private TextView textViewEN;
        private TextView textViewTR;
        private CardView kelime_card;
//constructer ile bağlıyoruz
        public CardTasarımTut(@NonNull View itemView) {
            super(itemView);
            textViewEN=itemView.findViewById(R.id.textViewEN);
            textViewTR=itemView.findViewById(R.id.textViewTR);
            kelime_card=itemView.findViewById(R.id.kelime_card);
        }
    }
}
