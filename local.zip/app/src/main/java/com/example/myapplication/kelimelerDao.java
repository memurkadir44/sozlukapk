package com.example.myapplication;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class kelimelerDao {
    public ArrayList<kelimeler> tumkelimeler(veritabani  vt){
        ArrayList<kelimeler>kelimelerArrayList=new ArrayList<>();
        SQLiteDatabase db=vt.getWritableDatabase();
        Cursor c=db.rawQuery("SELECT *FROM kelimeler",null);
        while(c.moveToNext()){
            @SuppressLint("Range") kelimeler k=new kelimeler (
                    c.getInt(c.getColumnIndex("kelime_id")),
                    c.getString(c.getColumnIndex("ingilizce")),
                    c.getString(c.getColumnIndex("turkce")));
            kelimelerArrayList.add(k);
        }
        return kelimelerArrayList;
    }
    public ArrayList<kelimeler> kelimeara(veritabani vt, String aramakelime){
        ArrayList<kelimeler>kelimelerArrayList=new ArrayList<>();
        SQLiteDatabase db=vt.getWritableDatabase();
        Cursor c=db.rawQuery("SELECT *FROM kelimeler WHERE ingilizce like'%"+aramakelime+"%'",null);
        while(c.moveToNext()){
            @SuppressLint("Range") kelimeler k=new kelimeler (
                    c.getInt(c.getColumnIndex("kelime_id")),
                    c.getString(c.getColumnIndex("ingilizce")),
                    c.getString(c.getColumnIndex("turkce")));
            kelimelerArrayList.add(k);
        }
        return kelimelerArrayList;
    }
}
