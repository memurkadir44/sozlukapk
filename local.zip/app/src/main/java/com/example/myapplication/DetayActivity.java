package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetayActivity extends AppCompatActivity {
    private TextView textViewenn;
    private TextView textView2tr;
    private kelimeler kelime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay);
        textViewenn=findViewById(R.id.textViewenn);
        textView2tr=findViewById(R.id.textView2tr);
   kelime=(kelimeler) getIntent().getSerializableExtra("nesne");
   textViewenn.setText(kelime.getIngilizce());
   textView2tr.setText(kelime.getTurkce());
    }
}